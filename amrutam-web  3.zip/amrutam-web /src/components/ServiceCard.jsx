

const ServiceCard = () => {
  return (
    <>
    </>
  );
};

export default ServiceCard;